import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'core/constants/colors.dart';
import 'core/constants/app_constants.dart';
import 'core/utils/routes.dart';
import 'data/providers/cart_provider.dart';
import 'core/services/auth_service.dart';

// Feature imports
import 'features/auth/pages/login_page.dart';
import 'features/auth/pages/signup_page.dart';
import 'features/home/pages/home_page.dart';
import 'features/product/pages/product_detail_page.dart';
import 'features/cart/pages/cart_page.dart';
import 'features/cart/pages/checkout_page.dart';
import 'features/profile/pages/profile_page.dart';
import 'features/profile/pages/orders_page.dart';
import 'features/profile/pages/settings_page.dart';
import 'features/admin/pages/admin_dashboard_page.dart';
import 'features/product/pages/product_review_page.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthService()),
        ChangeNotifierProvider(create: (_) => CartProvider()),
      ],
      child: MaterialApp(
        title: AppConstants.appName,
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(
            seedColor: AppColors.primary,
            primary: AppColors.primary,
            secondary: AppColors.secondary,
            background: AppColors.background,
            surface: AppColors.surface,
            error: AppColors.error,
            onPrimary: AppColors.onPrimary,
            onSecondary: AppColors.onSecondary,
          ),
          scaffoldBackgroundColor: AppColors.background,
          useMaterial3: true,
        ),
        initialRoute: AppRoutes.login,
        routes: {
          AppRoutes.login: (context) => const LoginPage(),
          AppRoutes.signup: (context) => const SignupPage(),
          AppRoutes.home: (context) => const HomePage(),
          AppRoutes.cart: (context) => const CartPage(),
          AppRoutes.checkout: (context) => const CheckoutPage(),
          AppRoutes.profile: (context) => const ProfilePage(),
          AppRoutes.admin: (context) => const AdminDashboardPage(),
          AppRoutes.orders: (context) => const OrdersPage(),
          AppRoutes.settings: (context) => const SettingsPage(),
        },
        onGenerateRoute: (settings) {
          // Handle dynamic routes like product detail
          if (settings.name?.startsWith('/product/') ?? false) {
            final productId = settings.name!.split('/').last;
            return MaterialPageRoute(
              builder: (context) => ProductDetailPage(productId: productId),
            );
          }

          // Handle product reviews page
          if (settings.name?.startsWith('/product-reviews/') ?? false) {
            final productId = settings.name!.split('/').last;
            return MaterialPageRoute(
              builder: (context) => ProductReviewPage(productId: productId),
            );
          }
          return null;
        },
      ),
    );
  }
}
