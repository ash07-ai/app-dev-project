import 'package:flutter/material.dart';

class AppColors {
  static const Color primary = Color(0xFF3366CC);
  static const Color secondary = Color(0xFF66BB6A);
  static const Color accent = Color(0xFFFFA726);
  static const Color background = Color(0xFFF5F5F5);
  static const Color surface = Color(0xFFFFFFFF);
  static const Color error = Color(0xFFE57373);
  static const Color onPrimary = Color(0xFFFFFFFF);
  static const Color onSecondary = Color(0xFFFFFFFF);
  static const Color textPrimary = Color(0xFF333333);
  static const Color textSecondary = Color(0xFF666666);
}