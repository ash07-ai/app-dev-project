import 'package:flutter/material.dart';
import '../../../core/constants/colors.dart';
import '../../../core/utils/routes.dart';
import '../../../data/mock_data/mock_users.dart';
import '../../../data/models/user.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    // In a real app, this would come from authentication state
    final User user = MockUsers.users[0];

    return Scaffold(
      appBar: AppBar(
        title: const Text('My Profile'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Profile header
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    // Profile image
                    CircleAvatar(
                      radius: 40,
                      backgroundImage: NetworkImage(user.profileImage ?? ''),
                      onBackgroundImageError: (_, __) {},
                      child: user.profileImage == null
                          ? Text(
                              user.name[0].toUpperCase(),
                              style: const TextStyle(
                                fontSize: 30,
                                fontWeight: FontWeight.bold,
                              ),
                            )
                          : null,
                    ),
                    const SizedBox(width: 16),
                    
                    // User details
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            user.name,
                            style: const TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            user.email,
                            style: TextStyle(
                              color: AppColors.textSecondary,
                            ),
                          ),
                          if (user.isAdmin) ...[  
                            const SizedBox(height: 8),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 8,
                                vertical: 4,
                              ),
                              decoration: BoxDecoration(
                                color: AppColors.primary.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(4),
                              ),
                              child: Text(
                                'Admin',
                                style: TextStyle(
                                  color: AppColors.primary,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 12,
                                ),
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),
                    
                    // Edit button
                    IconButton(
                      icon: const Icon(Icons.edit),
                      onPressed: () {
                        // Navigate to edit profile
                      },
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            
            // Profile options
            Card(
              child: Column(
                children: [
                  _buildProfileOption(
                    context,
                    icon: Icons.person,
                    title: 'Account Settings',
                    onTap: () {
                      Navigator.pushNamed(context, AppRoutes.settings);
                    },
                  ),
                  const Divider(height: 1),
                  _buildProfileOption(
                    context,
                    icon: Icons.shopping_bag,
                    title: 'My Orders',
                    onTap: () {
                      Navigator.pushNamed(context, AppRoutes.orderHistory);
                    },
                  ),
                  const Divider(height: 1),
                  _buildProfileOption(
                    context,
                    icon: Icons.favorite,
                    title: 'Wishlist',
                    onTap: () {
                      Navigator.pushNamed(context, AppRoutes.favorites);
                    },
                  ),
                  const Divider(height: 1),
                  _buildProfileOption(
                    context,
                    icon: Icons.location_on,
                    title: 'Shipping Addresses',
                    onTap: () {},
                  ),
                  const Divider(height: 1),
                  _buildProfileOption(
                    context,
                    icon: Icons.payment,
                    title: 'Payment Methods',
                    onTap: () {},
                  ),
                  if (user.isAdmin) ...[  
                    const Divider(height: 1),
                    _buildProfileOption(
                      context,
                      icon: Icons.admin_panel_settings,
                      title: 'Admin Dashboard',
                      onTap: () {
                        Navigator.pushNamed(context, AppRoutes.admin);
                      },
                    ),
                  ],
                ],
              ),
            ),
            const SizedBox(height: 16),
            
            // Support and logout
            Card(
              child: Column(
                children: [
                  _buildProfileOption(
                    context,
                    icon: Icons.help,
                    title: 'Help & Support',
                    onTap: () {},
                  ),
                  const Divider(height: 1),
                  _buildProfileOption(
                    context,
                    icon: Icons.info,
                    title: 'About Us',
                    onTap: () {},
                  ),
                  const Divider(height: 1),
                  _buildProfileOption(
                    context,
                    icon: Icons.logout,
                    title: 'Logout',
                    textColor: Colors.red,
                    onTap: () {
                      _showLogoutDialog(context);
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProfileOption(
    BuildContext context, {
    required IconData icon,
    required String title,
    required VoidCallback onTap,
    Color? textColor,
  }) {
    return ListTile(
      leading: Icon(icon, color: textColor ?? AppColors.primary),
      title: Text(
        title,
        style: TextStyle(color: textColor),
      ),
      trailing: const Icon(Icons.chevron_right),
      onTap: onTap,
    );
  }

  void _showLogoutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Logout'),
        content: const Text('Are you sure you want to logout?'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              // In a real app, you would clear authentication state here
              Navigator.pushReplacementNamed(context, AppRoutes.login);
            },
            child: const Text(
              'Logout',
              style: TextStyle(color: Colors.red),
            ),
          ),
        ],
      ),
    );
  }
}